title: ' NullPointerException'
date: '2019-09-15 11:32:08'
updated: '2019-09-15 15:58:28'
tags: ['null', nullpointer, exception]
permalink: /articles/2019/09/15/1568518328417.html
---
![](https://img.hacpai.com/bing/20190202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

什么是空指针异常（java.lang.NullPointerException）以及它们的原因是什么？

可以使用哪些方法/工具来确定原因，以便停止异常导致程序过早终止？

声明引用变量（即对象）时，实际上是在创建指向对象的指针。请考虑以下代码，其中声明基本类型int的变量：

```
int x;
x = 10;
```
在此示例中，变量x是一个int，Java会将它初始化为0。在第二行上为其分配值10时，将值10写入x引用的内存位置。

但是，当您尝试声明引用类型时，会发生不同的事情。请使用以下代码：

```
整数
num = new整数（10）;
```
第一行声明了一个名为num的变量，但它实际上并不包含原始值。相反，它包含一个指针（因为类型是Integer，它是一个引用类型）。由于你尚未说明要指出什么，Java将其设置为null，这意味着“我指向什么都没有”。

在第二行中，new关键字用于实例化（或创建）Integer类型的对象，指针变量num分配给该Integer对象。

声明变量但未创建对象时发生NullPointerException。所以你指的是实际上并不存在的东西。

如果尝试取消引用num BEFORE在创建对象之前会出现NullPointerException。在最琐碎的情况下，编译器将捕获问题并让您知道“num可能尚未初始化”，但有时您可能编写不直接创建对象的代码。

例如，您可能有如下方法：

```
public void doSomething（SomeObject obj）{
   //对obj做点什么
}
```
在这种情况下，您不是创建对象obj，而是假设它是在调用doSomething（）方法之前创建的。注意，可以像这样调用方法：

doSomething的（NULL）;
在这种情况下，obj为null。如果该方法旨在对传入的对象执行某些操作，则抛出NullPointerException是合适的，因为它是程序员错误，并且程序员将需要该信息用于调试目的。

或者，可能存在这样的情况：该方法的目的不仅仅是对传入的对象进行操作，因此可以接受空参数。在这种情况下，您需要检查null参数并采取不同的行为。您还应该在文档中解释这一点。例如，doSomething（）可以写成：

```
public void doSomething（SomeObject obj）{
    if（obj！= null）{
       //做一点事
    } else {
       //做点别的
    }
}
```
