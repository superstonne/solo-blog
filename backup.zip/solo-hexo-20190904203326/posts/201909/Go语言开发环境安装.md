title: Go 语言开发环境安装
date: '2019-09-01 15:03:38'
updated: '2019-09-01 15:03:38'
tags: [go, go开发环境, go环境变量, gohelloworld]
permalink: /articles/2019/09/01/1567321418649.html
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> Go 是一个开源的编程语言，它能让构造简单、可靠且高效的软件变得容易。

Go是从2007年末由Robert Griesemer, Rob Pike, Ken Thompson主持开发，后来还加入了Ian Lance Taylor, Russ Cox等人，并最终于2009年11月开源，在2012年早些时候发布了Go 1稳定版本。现在Go的开发已经是完全开放的，并且拥有一个活跃的社区。
#### 安装 Go 开发环境

1. 在[官网](https://golang.google.cn/dl/)下载你的操作系统对应的安装包。

2. 安装包下载好后，双击运行安装包，一直下一步即可。

3. 打开终端输入：go，然后回车。如果看到如下输出，那么恭喜你，Go 已经成功的安装到了你的设备上。

```

~ » go

Go is a tool for managing Go source code.

Usage:

go <command> [arguments]

The commands are:

bug start a bug report

build compile packages and dependencies

clean remove object files and cached files

doc show documentation for package or symbol

env print Go environment information

fix update packages to use new APIs

fmt gofmt (reformat) package sources

generate generate Go files by processing source

get download and install packages and dependencies

install compile and install packages and dependencies

list list packages or modules

mod module maintenance

run compile and run Go program

test test packages

tool run specified go tool

version print Go version

vet report likely mistakes in packages

Use "go help <command>" for more information about a command.

Additional help topics:

buildmode build modes

c calling between Go and C

cache build and test caching

environment environment variables

filetype file types

go.mod the go.mod file

gopath GOPATH environment variable

gopath-get legacy GOPATH go get

goproxy module proxy protocol

importpath import path syntax

modules modules, module versions, and more

module-get module-aware go get

packages package lists and patterns

testflag testing flags

testfunc testing functions

Use "go help <topic>" for more information about that topic.

------------------------------------------------------------

~ »

```

#### 开始你的 Hello World

创建一个文件名为 HelloWorld.go 的文件，然后向其中输入如下内容：

```

package main

import "fmt"

func main() {

fmt.Printf("hello, world\n")

}

```

打开终端输入：go build HelloWorld.go，命令运行结束后，会在和你源码相同的目录下生成一个可执行文件：HelloWorld。然后我们运行该文件就会得到程序的输入：

```

~/developer/go/src » ./HelloWorld

hello, world

~/developer/go/src »

```

至此，你的 Go 语言开发环境已经搭建完毕。
