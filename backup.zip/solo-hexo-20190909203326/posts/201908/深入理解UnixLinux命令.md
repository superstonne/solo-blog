title: 深入理解 Unix / Linux 命令
date: '2019-08-17 20:02:57'
updated: '2019-08-17 20:04:15'
tags: [unix, command, unix命令]
permalink: /articles/2019/08/17/1566043377320.html
---
![](https://img.hacpai.com/bing/20190513.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**1. 命令的剖析**







Unix 的命令由2部分组成，命令本身和附加的参数。例如 ls 命令，如果直接执行 ls 命令，不带附加参数，那么默认执行的目标即为当前目录，如下







```

[root@localhost /]$ls

bin   dev   etc   lib    media  opt   root  sbin  sys  usr

boot  docs  home  lib64  mnt    proc  run   srv   tmp  var

```







我们可以添加命令参数，来使得它更加灵活, -l 参数可以使得结果集是以长结果显示更多信息，后面的路径可以指定命令执行的目标路径







```

[root@localhost /]$ls -l /root

total 181328

-rw-------. 1 root root      1264 Aug 15 19:36 anaconda-ks.cfg

drwxr-xr-x. 3 root root        18 Sep  1 22:12 backups

-rw-r--r--. 1 root root      2381 Sep  1 21:35 baidu.html

-rwxr-xr-x. 1 root root        10 Sep  1 05:57 cat.txt

drwxr-xr-x. 2 root root        25 Sep  1 21:43 docs

-r--r--r--. 2 root root        17 Aug 18 12:18 file

-r--r--r--. 2 root root        17 Aug 18 12:18 ha_link

-rw-r--r--. 1 root root        49 Aug 18 12:14 hard_link

drwxr-xr-x. 7   10  143       245 Aug 26 11:44 jdk1.8

-rw-r--r--. 1 root root 185646832 Aug 26 11:30 jdk-8u181-linux-x64.tar.gz

-rw-r--r--. 1 root root         0 Sep  1 22:18 log.file

-rw-r--r--. 1 root root         0 Sep  1 23:36 log.fileat

-rwxr--r--. 1 root root       114 Sep  2 06:53 purple.sh

lrwxrwxrwx. 1 root root         4 Aug 18 12:08 soft_link -> file

-rw-r--r--. 1 root root      1326 Aug 22 12:01 test.txt

```



**2. 查找命令相关的信息**



如果你从未使用过 ls 命令，该如何学习它如何使用呢？除了通过搜索引擎学习，你还可以使用 man 来学习所有你想学习的指令。如下展示了 man ls 命令执行后的输出结果，由于篇幅过长，省略了后面部分，有兴趣的朋友自行尝试



```

[root@localhost /]$man ls





LS(1)                            User Commands                           LS(1)



NAME

       ls - list directory contents



SYNOPSIS

       ls [OPTION]... [FILE]...



DESCRIPTION

       List  information  about  the FILEs (the current directory by default).

       Sort entries alphabetically if none of -cftuvSUX nor --sort  is  speci‐

       fied.



       Mandatory  arguments  to  long  options are mandatory for short options

       too.



       -a, --all





GNU coreutils 8.22               November 2016                           LS(1)

 Manual page ls(1) line 219/251 (END) (press h for help or q to quit)

```



从输出中我们可以了解到该命令的主要功能和支持的所有参数。除了使用 man 来学习命令，我们还可以使用 info 来学习。例如命令行输入 info ls：



```

[root@localhost /]$info ls



File: coreutils.info,  Node: ls invocation,  Next: dir invocation,  Up: Directory listin\

g



10.1 'ls': List directory contents

==================================



The 'ls' program lists information about files (of any type, including

directories).  Options and file arguments can be intermixed arbitrarily,

as usual.



   For non-option command-line arguments that are directories, by

default 'ls' lists the contents of directories, not recursively, and

omitting files with names beginning with '.'.  For other non-option

arguments, by default 'ls' lists just the file name.  If no non-option

argument is specified, 'ls' operates on the current directory, acting as

if it had been invoked with a single argument of '.'.

  ...

```



该操作同样会告诉你如何使用 ls 来高效化你的工作。



**3****. 修改命令**







我们可以使用一些工具来增强命令的功能，例如元字符，输入输出重定向，管道，命令置换。







**元字符**







上面延时的 ls 命令输出了很多文件，但是假如我们只需要列出，文件名末尾是 link 结尾的文件，可以如何操作呢？我们可以使用参数 + 通配符来完成这个功能。







```

[root@localhost ~]$ls *link

ha_link  hard_link  soft_link

```







\* 代表匹配文件名中的一个或多个字符。



？ 匹配文件名中的任何一个字符。



[] 匹配包含在 [] 符号内的某个字符即可。







```

[root@localhost ~]$ls *[link]

baidu.html  ha_link  hard_link  soft_link

```







如上匹配除了结尾最后一个字符是 l，i，n，k 任何一个字符的所有文件。







**输出，输出重定向**







上述我们操作的命令执行结果都是直接输出到了控制台，但是假如我们的输出结果很长，或者暂时有其他事情要做，结果需要等稍后去分析该怎么办呢？这个时候我们可以将结果输出重定向到到一个文件中，保存起来，稍后查看。







```

[root@localhost ~]$ls *[link] > links.txt

[root@localhost ~]$cat links.txt

baidu.html

ha_link

hard_link

soft_link

```







如上操作，我们便将文件列表的结果输出到了 links.txt 文件中，以便稍后调查问题。







**管道**







刚刚我们查看的是用户工作目录下的文件，输出很少，可以直接查看。但是当我们查询一个文件夹下面有很多文件的时候，输出结果很长，此时一个屏幕都无法展示结果，查看并不方便。有没有一种方法，可以让我们先查看一部分结果，查看完毕后，按下一个键继续查看下一页呢？也许聪明的你会想到 more 或者 less 命令。但是这俩个命令是来查看文件的，此时管道可以帮助你。管道可以使得输入输出重定向，将一个命令的输出作为另外一个命令的输入。







```

[root@localhost ~]$ls /etc | more

adjtime

aliases

aliases.db

alternatives

anacrontab

asound.conf

at.deny

audisp

audit

bash_completion.d

bashrc

binfmt.d

centos-release

centos-release-upstream

--more--

```







如上，ls 的输出结果，作为了 more 的输入，这样我们就可以优哉游哉的慢慢查看 ls 的结果。当然这里只是用 ls 和 more 来举例，朋友们可以自己去探索其他的命令结合管道来使用，你会爱上它的。







**命令置换**







同样，命令置换也可以达到像管道一样的操作。它也将命令的输出结果作为另外一个命令输入。







```

[root@localhost ~]$ls ${pwd}

anaconda-ks.cfg  cat.txt  ha_link    jdk-8u181-linux-x64.tar.gz  log.fileat  test.txt

backups          docs     hard_link  links.txt                   purple.sh

baidu.html       file     jdk1.8     log.file                    soft_link

```







如上，我们将 pwd 命令的输出（当前工作目录），作为 ls 命令的输入。当然该命令也可以用管道来实现：pwd | ls，达到同样的效果：







```

[root@localhost ~]$pwd | ls

anaconda-ks.cfg  cat.txt  ha_link    jdk-8u181-linux-x64.tar.gz  log.fileat  test.txt

backups          docs     hard_link  links.txt                   purple.sh

baidu.html       file     jdk1.8     log.file                    soft_link

```







实现的同样的效果，但是实现原理不同。命令置换是通过在子 shell 中执行结果，然后将结果返回到主 shell 中。而管道则一直在主 shell 中执行。







—————END—————







喜欢本文的朋友们，欢迎长按下图订阅，收看更多精彩内容
![公众号二维码.jpg](https://img.hacpai.com/file/2019/08/公众号二维码-0c081115.jpg)

