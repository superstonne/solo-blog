title: 如何使用优雅的使用 VI 编辑器
date: '2019-08-17 19:37:40'
updated: '2019-08-17 19:55:54'
tags: [vi, vim, linux编辑文件, wq]
permalink: /articles/2019/08/17/1566041860696.html
---
![](https://img.hacpai.com/bing/20190214.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


*使用 Linux 操作系统，免不了要编辑文件。编辑文件，我选择 VI。*



编辑文件无非几个操作：打开 / 创建文件，在文件中移动，搜索文件内容，编辑文件，保存文件。接下来我们就从这几个维度来学习一下宇宙最强编辑器 VI。



### 1. 打开 /  创建文件



控制台输入 vi 可以打开一个空的面板，就和你打开一个 windows 的记事本一样。此时 vi 处于命令模式，在该模式下，我们可以使用 vi 命令来完成一些文件操作，就像文章开头提到的：移动，搜索，保存等。    



```

Wow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~                                                                   ~                                                                   ~ 

```



接下来我们可以在该面板上输入内容，或者退出该面板，亦或者保存这个面板的内容到一个文件中（这时候我们需要指定文件文件）。输入命令 ：w 来保存文件试一下



```

~~:wq

```



按下 enter 键以后，我们会收到一个提示来告诉我们需要输入一个文件名才能保存文件。



```

~~E32: No file name

```



那我们来输入一个文件名 ：wq test.txt



```

~~:wq test.txt

```



按下 enter 键，面板消失了，查看当前工作目录，我们可以看到 test.txt 已经被创建出来了。



```

[root@localhost ~]$lltotal 181328-rw-r--r--. 1 root root         0 Sep  9 11:14 test.txt[root@localhost ~]$

```



既然文件创建出来了，那么如何打开它呢？控制台输入 vi test.txt，即可打开该文件。当然我们也可以 vi -r test.txt 来以只读的方式打开 test.txt，在这种模式下我们无法修改文件内容，在看一下比较敏感的配置文件时候比较有用，防止误操作破坏了文件内容。



```

[root@localhost ~]$vi test.txt~~~~~"test.txt" 0L, 0C

```



### 2. 编辑文件



好吧，那就来输入一些内容，输入命令 i，接着面板发生了变化



```

~~-- INSERT --

```



敲击键盘输入：Hello vi， i'm using you。



```

Hello vi， i'm using you~~~-- INSERT --

```



接着我们需要按一下 Esc 键来从编辑模式回到命令模式。你会发现面板底部的，-- INSERT -- 消失了，此时代表我们已经回到了命令模式，此时我们敲击键盘就是在发送 VI 命令给编辑器，当我们能看到 -- INSERT -- 的时候，则是在编辑模式下，我们敲击键盘，即为修改文件内容。我们接着上面继续输入命令 ：w ，然后按下 enter 键，即可执行我们输入的这条命令。面板底部会提示告诉我们已经写了多少个字符了



```

~~~~"test.txt" 1L, 24C written

```



来吧，让我们输入更多的字符。上面我们使用 i 在光标之后开始输入。我们使用 I 命令可以在光标所在的行首来继续我们的编辑操作。



```

Ha Ha, I am tying content in the head. Hello vi, i'm using you~~-- INSERT --

```



 此时我们已经在第一行输入了太多的内容。我想新开一行继续编写，按下 Esc 回到命令模式，输入 o 命令，在光标的下方会创建一个新的空行，愉快的继续输入吧



```

Ha Ha, I am tying content in the head. Hello vi, i'm using youOh, cool! It's a new line created by 'o' command.~~-- INSERT --

```



糟糕了，我忘记一行内容。我想在上面插入一行内容。输入 O 命令来在光标的上方创建一个新行（别忘了回到命令模式哟）



```

Ha Ha, I am tying content in the head. Hello vi, i'm using youWowwwww. It's new line inserted by 'O' commanOh, cool! It's a new line created by 'o' command.~~~~-- INSERT --

```



额，兴奋过头。我居然打错了单词 command，此时我已经到了命令模式。光标正好在最后一个字符 ‘n’ 上愉快的跳动着，此时我迫切的想要在修正这个单词。急切的我输入 i 命令，接着输入内容 d。



```

Ha Ha, I am tying content in the head. Hello vi, i'm using youWow. It's new line inserted by 'O' commadnOh, cool! It's a new line created by 'o' command.~~~-- INSERT --

```



事与愿违，i 命令是在光标位置之前插入内容。此时我们应该使用 a（append）命令来在光标之后输入内容。输入错了内容，让我们使用 x 命令来删除这个错误位置的字符 d。接着输入命令a，输入内容 d。这下就完美了。



```

Ha Ha, I am tying content in the head. Hello vi, i'm using youWow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~~~-- INSERT --

```



我们也可以使用命令 A 来在光标所在行的末尾来插入内容。一眨眼已经输入了这么多内容，有一些浮夸的字符我需要去掉。当然我们可以删除所有内容重新输入。这样就太蠢了，我们来使用 h（左），j（下），k（上），l（右） 来在文件中移动起来吧，移动到我们想要编辑的位置，然后使用编辑命令，来完善内容吧。【如果内容实在太多，我们可以使用 ctrl + F / B 来前后翻页】



让我们来移动到第一行的第一个字符 H 上面，Ha Ha，违和感太强了，删除它。使用 x 命令删除当前光标所在的字符，只需要按下 5 下 x 键即可删除这 5 个字符。等等，是不是有些累，可以输入 5x 来删除光标所在和光标之后的 5 个字符，试试吧。



```

, I am tying content in the head. Hello vi, i'm using youWow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~

```



Cool，内容已经被删除了。我们也可以使用 X 来删除光标之前的字符，此时也可以加上数字，删除从光标开始的 n 个字符。当然，我们也可以使用 dw 来删除一个单词。



```

in the head. Hello vi, i'm using youWow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~~~

```



第一行内容已经被操作的乱七八糟了，删除整行吧。恰好光标在行首，使用 D 来删除，从光标开始直接行末的所有字符。



```

Wow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~~~~

```



此时光标处于行首，光秃秃的该行没有任何内容。可以在删除内容的同时将空行也消失掉吗？可以！输入命令 u 来回退上一个操作。接着输入 dd 来删除光标所在行的内容



```

Wow. It's new line inserted by 'O' commandOh, cool! It's a new line created by 'o' command.~~~

```



记住，这些命令之前都可以加上一个数字，输在代表重复执行该命令的次数。2dd 即代表连着执行 2 此删除行内容操作。



上面介绍的几个命令，操作完成后仍然处于命令模式。那么有没有命令操作完后，直接让我们进入编辑模式呢？



使用 cc 来删除当前行的内容，执行结束后直接进入插入模式来编辑内容。 cw 删除当前单词，结束后直接进入编辑模式。



```

The line has been deleted by 'cc' command, it's the new content.Oh, cool! It's a new line created by 'o' command.~~~

```



cw 删除 The，输入 Old 来替换 The



```

Old line has been deleted by 'cc' command, it's the new content.Oh, cool! It's a new line created by 'o' command.~~~

```



糟糕，我突然觉得 Old 不够好，想换回 The。输入 R 命令，接着输入吧，输入会替换当前光标所在字符为输入字符。操作结束后，按 Esc 退出替换模式，回到命令模式。如果我们只想替换一个字符，则可以使用 r 命令，然后输入替换字符，输入后即可自动回到命令模式。



忽然，我发现 oh， cool写的不够通顺。想去更改一下。移动光标到Oh 后面的逗号上，输入 命令 s，接着输入 ‘。’ 将逗号替换为了句号，此时已经处于插入模式，输入 it's 



```

Old line has been deleted by 'cc' command, it's the new content.Oh. It's cool! It's a new line created by 'o' command.~~

```



如果你看这一整行的内容都不顺眼，则可以使用 S 删除一整行的内容，并且自动进入插入模式，愉快的重写。



```

Old line has been deleted by 'cc' command, it's the new content.The line has been deleted by 'S' and rewrite.~~

```



前面的 2 行的内容似乎可以合并在一行里面显示，此时光标处于第一行，使用 J 命令来合并它们吧。



```

Old line has been deleted by 'cc' command, it's the new content.  The line has been deleted by 'S' and rewrite. ~                                                                          ~     

```



2 行内容被完美的拼接起来了。接着我要将这一行的内容重复一下，来强调它的重要性。使用 yy 命令来复制它们，或者使用 yw 来复制我中意的一个单词。复制到剪贴板以后，我们需要将它拖拽到我们想要放置的位置。使用 p 来将它们放置到光标的后面一行，或者使用 P 来放置到光标的前面一行。



怎么样？有没有操作的很爽。奥，不要忘记，这些命令之前都是可以加上数字的哦。



### 3. 搜索文件



写了这么多内容了，那么如何在内容中查找一下是不是存在某个单词呢？输入 / 命令，即可执行搜索操作了。



```

Hi, i'm here.Hey, how are you.~~~~/are

```



### 4. 执行命令



假如我们在编辑文件的同时，想知道当前工作目录的文件列表。如果退出编辑器查看，再回来编辑就太麻烦了。我们可以使用 ：！ command 来执行我们命令。



```

[root@localhost ~]$vi test.txt[No write since last change]anaconda-ks.cfg  docs	    jdk1.8			log.fileat  test.txtbackups		 file	    jdk-8u181-linux-x64.tar.gz	purple.shbaidu.html	 ha_link    links.txt			soft_linkcat.txt		 hard_link  log.file			test2.txtPress ENTER or type command to continue[No write since last change]anaconda-ks.cfg  docs	    jdk1.8			log.fileat  test.txtbackups		 file	    jdk-8u181-linux-x64.tar.gz	purple.shbaidu.html	 ha_link    links.txt			soft_linkcat.txt		 hard_link  log.file			test2.txtPress ENTER or type command to continue

```



按照提示，内容查看完毕后。输入任何内容即可重新回到编辑器。



### 5. 替换内容



在修改配置文件的时候，难免会有一些替换的操作。文件内容如下，我们想替换掉 you 为 to。则可以如下操作：



```

Hi, i'm here.Hey, how are you.I'm fine, thank you. Who are you.~~~:1,$s/you/to/g

```



1 代表从第一行开始，$ 代表直到最后一行，you 是被替换字符串，to 是替换为的字符串，g 代表替换改行的所有匹配。我们也可以在 g 后面加上 c，代表匹配到以后需要确认是否替换。假如有一些特殊字符在里面，我们也可以使用 \ 来转义。



至此我们已经学习了不少 VI 命令，需要真正的掌握这些需要不断的使用和练习，加油吧。







—————END—————



喜欢本文的朋友们，欢迎长按下图关注订阅号**码农尼克**，收看更多精彩内容


![公众号二维码.jpg](https://img.hacpai.com/file/2019/08/公众号二维码-751bffbb.jpg)

